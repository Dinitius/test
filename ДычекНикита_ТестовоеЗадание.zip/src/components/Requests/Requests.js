import React, {useEffect, useState} from "react";

import ModalAdd from "../ModalAdd/ModalAdd";
import ModalEdit from "../ModalEdit/ModalEdit";

import './Requests.css'

function Requests() {
    const [isUpdated, setIsUpdated] = useState(false)
    const [isEditModalVisible, setIsEditModalVisible] = useState(false)
    const [isAddModalVisible, setIsAddModalVisible] = useState(false)
    const [taskData, setTaskData] = useState(null)
    const [tasks, setTasks] = useState(null)

    useEffect(() => {
        getToken()
            .then(() => {
                getTasks()
                    .then((allTasks) => {
                        setTasks(allTasks.value)
                    })
            })
    }, [])

    useEffect(async () => {
        if (!!isUpdated) {
            const allTasks = await getTasks()

            setTasks(allTasks.value)
            setIsUpdated(false)
        }
    }, [isUpdated])

    const updateTaskStatus = () => {
        setIsUpdated(true)
    }

    const getToken = async () => {
        const response = await fetch('http://intravision-task.test01.intravision.ru/api/Tenants')
        const token = await response.json()
        if (token) {
            localStorage.setItem('userData', JSON.stringify({
                userToken: token
            }))
        }
        return token
    }

    const getTasks = async () => {
        const token = JSON.parse(localStorage.getItem('userData'))
        const response = await fetch(`http://intravision-task.test01.intravision.ru/odata/tasks?tenantguid=${token.userToken}`)
        if (!response.ok) {
            throw new Error(`Произошла ошибка ${response.status}`);
        }
        const allTasks = await response.json()
        return allTasks
    }

    const getTaskById = async (id) => {
        const token = JSON.parse(localStorage.getItem('userData'))
        const response = await fetch(`http://intravision-task.test01.intravision.ru/api/${token.userToken}/Tasks/${id}`)
        if (!response.ok) {
            throw new Error(`Произошла ошибка ${response.status}`);
        }
        const taskInfo = await response.json()
        return taskInfo
    }

    const handleAddModal = () => {
        setIsAddModalVisible(!isAddModalVisible)
    }
    const handleEditModal = () => {
        setIsEditModalVisible(!isEditModalVisible)
    }

    const editRequest = async (event) => {
        if (event.target.localName === 'td') {
            const requestId = event.target.parentElement.children[0].getAttribute('id')
            await getTaskById(requestId)
                .then((taskData) => {
                    setTaskData(taskData)
                })
            handleEditModal()
        }
    }

    return (
        <>
            <div className="container">
                <div className="createBtn">
                    <button className="createReq" onClick={handleAddModal}>Создать заявку</button>
                </div>
                <table className="table">
                    <thead className="thead">
                    <tr className="title">
                        <th className="elem id">ID</th>
                        <th className="elem name">Название</th>
                        <th className="elem elemStatus">Статус</th>
                        <th className="elem doer">Исполнитель</th>
                    </tr>
                    </thead>
                    <tbody>
                    {
                        tasks && tasks.map((task, index) => {
                            const color = {
                                '--borderLeft': `${task.statusRgb}`
                            }
                            return (
                                <tr className="request" key={index} onClick={editRequest}>
                                    <td className="elem id" id={task.id} style={color}>{task.id}</td>
                                    <td className="elem name">{task.name}</td>
                                    <td className="elem elemStatus">
                                        <span className='stColor' style={{'backgroundColor': task.statusRgb}}>
                                            {task.statusName}
                                        </span>
                                    </td>
                                    <td className="elem doer">{task.initiatorName}</td>
                                </tr>
                            )
                        })
                    }
                    </tbody>
                </table>
                {isAddModalVisible && <ModalAdd closeModal={handleAddModal} updateTaskStatus={updateTaskStatus}/>}
                {isEditModalVisible && <ModalEdit updateTaskStatus={updateTaskStatus} closeModal={handleEditModal} taskInfo={taskData}/>}
            </div>
        </>
)}

export default Requests
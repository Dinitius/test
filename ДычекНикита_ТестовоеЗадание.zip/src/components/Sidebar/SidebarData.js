import React from 'react'

export const base = require('../../assets/img/base.png');
export const SidebarData = [
    {
        title: 'База знаний',
        path: '/',
        icon: 'https://i.ibb.co/nBCrZ64/base.png'
    },
    {
        title: 'Заявки',
        path: '/',
        icon: 'https://i.ibb.co/drYdKz7/req.png'
    },
    {
        title: 'Сотрудники',
        path: '/',
        icon: 'https://i.ibb.co/m9Fw3bS/empl.png'
    },
    {
        title: 'Клиенты',
        path: '/',
        icon: 'https://i.ibb.co/vBqzfxh/clients.png'
    },
    {
        title: 'Активы',
        path: '/',
        icon: 'https://i.ibb.co/q1p2Tpt/analytics.png'
    },
    {
        title: 'Настройки',
        path: '/',
        icon: 'https://i.ibb.co/PmPX8DC/settings.png'
    },
]
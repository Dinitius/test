import React from 'react'
import { Link } from 'react-router-dom'
import { SidebarData } from "./SidebarData"
import logo from '../../assets/img/logo.png'

import './Sidebar.css';

function Sidebar() {
    return (
        <>
            <div className="sidebarWrapper">
                <nav className="sideBar">
                        <img className="logo" src={logo} alt="logo"/>
                    <ul className="sideBar-items">
                        {SidebarData.map((item, index) => {
                            return (
                                <li key={index} className="sb-item">
                                    <Link to={item.path} className="flex">
                                        <img src={item.icon} alt={item.title}/>
                                        <span>{item.title}</span>
                                    </Link>
                                </li>
                            )
                        })}
                    </ul>
                </nav>
            </div>
        </>
    )
}

export default Sidebar

import React, {useState} from 'react'

import './ModalAdd.css'

const ModalAdd = ({closeModal, updateTaskStatus}) => {
    const [form, setForm] = useState({
        name: '',
        description: ''
    })
    const token = JSON.parse(localStorage.getItem('userData'))

    const changeHandler = (event) => {
        setForm({...form, [event.target.name]: event.target.value})
    }

    const addNewRequest = async (e) => {
        e.preventDefault()
        const requestBody = JSON.stringify({
            "name": form.name,
            "description": form.description
        })
        const response = await fetch(`http://intravision-task.test01.intravision.ru/api/${token.userToken}/Tasks`, {
            method: "POST",
            body: requestBody,
            headers: {
                'Content-Type' : 'application/json'
            }
        })

        if (response.ok) {
            updateTaskStatus()
            closeModal()
        }
    }

    return (
        <>
            <div className="addNewModal">
                <div className="modalHeader">
                    <h2 className="modalTitle">Новая заявка</h2>
                    <button className="closeModal" onClick={closeModal}>
                        <span>×</span>
                    </button>
                </div>

                <form className="modalForm" action="">
                    <div className="modalBody">
                        <div className="nameOfRequest">
                            <label className="requestNameLabel" htmlFor="requestName">Название</label>
                            <textarea
                                onChange={changeHandler}
                                className="textArea requestNameArea"
                                name="name"
                                id="requestName"
                                rows="5"></textarea>
                        <div className="descriptionOfRequest">
                            <label className="requestDescriptionLabel" htmlFor="requestDetails">Описание</label>
                            <textarea
                                onChange={changeHandler}
                                className=" textArea requestDescriptionArea"
                                name="description"
                                id="requestDetails"
                                rows="5"></textarea>
                        </div>
                    </div>
                    <input
                        onClick={addNewRequest}
                        className="saveNewRequest"
                        type="submit"
                        value="Сохранить"/>
                    </div>
                </form>
            </div>
        </>
    )
}

export default ModalAdd
import React from "react";

import './SearchForm.css'

function SearchForm() {
    return (
        <>
            <form className="searchForm" method="get">
                <input className="searchInput" type="search" />
                    <button className="searchBtn" value="" type="submit"></button>
            </form>
        </>
    )
}

export default SearchForm
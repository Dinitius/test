import React, {useEffect, useState} from 'react'

import './ModalEdit.css'

const ModalEdit = ({updateTaskStatus, closeModal, taskInfo}) => {
    const comments = taskInfo.lifetimeItems
    const [newComment, setNewComment] = useState('')
    const [users, setUsers] = useState(null)
    const [statusName, setStatusName] = useState(taskInfo.statusName)
    const [userName, setUserName] = useState(taskInfo.executorName)
    const [statusId, setStatusId] = useState()
    const [userId, setUserId] = useState()
    const [statuses, setStatuses] = useState(null)

    console.log(taskInfo.tags)

    useEffect(() => {
        getUsers()
            .then((users) => {
                setUsers(users)
                getUserById(taskInfo.executorId, users)
                return users
            })
    }, [])

    useEffect(() => {
        getStatusItems()
            .then((statuses) => {
                setStatuses(statuses)
            })
    }, [!statuses])

    const getUsers = async () => {
        const token = JSON.parse(localStorage.getItem('userData'))
        const response = await fetch(`http://intravision-task.test01.intravision.ru/api/${token.userToken}/Users`)
        if (!response.ok) {
            throw new Error(`Произошла ошибка ${response.status}`);
        }
        const users = await response.json()
        return users
    }

    const getUserById = (id, users) => {
        users && users.map((user) => {
            if (user.id === id) {
                return (user)
            }
        })
    }

    const getStatusItems = async () => {
        const token = JSON.parse(localStorage.getItem('userData'))
        const response = await fetch(`http://intravision-task.test01.intravision.ru/api/${token.userToken}/Statuses`)
        if (!response.ok) {
            throw new Error(`Произошла ошибка ${response.status}`);
        }
        const statuses = await response.json()
        return statuses
    }

    const toggleStatuses = () => {
        const statuses = document.querySelectorAll('.status')
        statuses.forEach((item) => {
          item.classList.toggle('hide')
        })
    }

    const toggleUsers = () => {
        const users = document.querySelectorAll('.user')
        users.forEach((item) => {
            item.classList.toggle('hide')
        })
    }

    const addNewEditRequest = async (e) => {
        e.preventDefault()
        const token = JSON.parse(localStorage.getItem('userData'))
        const requestBody = JSON.stringify({
            "id": taskInfo.id,
            "name": taskInfo.name,
            "description": taskInfo.description,
            "comment": newComment,
            "price": taskInfo.price,
            "taskTypeId": 0,
            "statusId": statusId,
            "priorityId": 0,
            "serviceId": 0,
            "resolutionDatePlan": "2021-03-02T14:57:03.072Z",
            "tags": [],
            "initiatorId": taskInfo.initiatorId,
            "executorId": userId,
            "executorGroupId": taskInfo.executorGroupId
        })
        const response = await fetch(`http://intravision-task.test01.intravision.ru/api/${token.userToken}/Tasks`, {
            method: "PUT",
            body: requestBody,
            headers: {
                'Content-Type' : 'application/json'
            }
        })
        if (response.ok) {
            updateTaskStatus()
            closeModal()
        }
    }

       return (
           <>
               <div className="addNewModal">
                   <div className="modalHeader">
                       <h2 className="modalTitle">№ {taskInfo.id}</h2>
                       <p className="reqTitle">{taskInfo.name}</p>
                       <button className="closeModal" onClick={closeModal}>
                           <span>×</span>
                       </button>
                   </div>
                   <div className="editModalBody">
                       <div className="leftSide">
                           <label className="newTitle" htmlFor="requestName">Описание</label>
                           <div className="description">{taskInfo.description}</div>
                           <textarea
                               onChange={e => setNewComment(e.target.value)}
                               className=" textArea addComment"
                               name="addComment"
                               value={newComment}
                               id="requestComment"
                               rows="3" placeholder="Добавление комментариев">
                           </textarea>
                           <input
                               onClick={addNewEditRequest}
                               className="saveNewRequest"
                               type="submit"
                               value="Сохранить"/>
                           <div className="comments">
                               {
                                   comments && comments.map((item, index) => {
                                       return (
                                           <div className="comment" key={index}>
                                               <span className="circle"></span>
                                               <h2 className="userName">{taskInfo.executorName}</h2>
                                               <p className="commentDate">{item.createdAt.toLocaleString()}</p>
                                               <div className="commentTextArea">
                                                   <p className="commentText">{item.comment}</p>
                                               </div>
                                           </div>
                                       )
                                   })
                               }
                           </div>
                   </div>
                   <div className="rightSide">
                       <p className="defaultStatus" onClick={toggleStatuses}>{statusName}</p>
                       <ul className="statuses">
                           {
                               statuses && statuses.map((item, index) => {
                                   return (
                                       <li className="status hide" key={index}
                                           onClick={() => {
                                               setStatusName(item.name)
                                               setStatusId(item.id)
                                               toggleStatuses()
                                           }}
                                       >{item.name}</li>
                                   )
                               })
                           }
                       </ul>
                       <div className="item">
                           <p className="itemTitle">Заявитель</p>
                           <p className="phonetic">{taskInfo.initiatorName}</p>
                       </div>
                       <div className="item">
                           <p className="itemTitle">Создана</p>
                           <p className="creator">{taskInfo.initiatorName}</p>
                       </div>
                       <div className="item">
                           <p className="itemTitle">Исполнитель</p>
                           <p className="defaultUser" onClick={toggleUsers}>{userName}</p>
                           <ul className="users">
                               {
                                   users && users.map((item, index) => {
                                       return (
                                           <li className="user hide" key={index}
                                               onClick={() => {
                                               setUserName(item.name)
                                                   setUserId(item.id)
                                               toggleUsers()
                                           }}>{item.name}</li>
                                       )
                                   })
                               }
                           </ul>

                       </div>
                       <div className="item">
                           <p className="itemTitle">Приоритет</p>
                           <p className="priority">{taskInfo.priorityName}</p>
                       </div>
                       <div className="item">
                           <p className="itemTitle">Срок</p>
                           <p className="term">{taskInfo.resolutionDatePlan}</p>
                       </div>
                       <div className="item">
                           <p className="item">Теги</p>
                           {
                               taskInfo.tags.map((item, index) => {
                                   return (
                                       <p className="itemTitle" key={index}>{item.name}</p>
                                   )
                               })
                           }
                       </div>
                       </div>
                   </div>
               </div>
               <div>
                   {/*{*/}
                   {/*    console.log('EDIT MODAL', taskInfo)*/}
                   {/*}*/}
               </div>
           </>
       )
}

export default ModalEdit
import React, { useState } from 'react'
import Sidebar from "../components/Sidebar/Sidebar";
import Requests from "../components/Requests/Requests";
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from "react-router-dom";

import '../App.css'

import SearchForm from '../components/SearchForm/SearchForm'

function Home() {

    return (
        <>
            <div className="mainWrapper">
                <Router>
                    <Sidebar />
                </Router>
                <SearchForm />
                <Requests />
            </div>
        </>
    )
}

export default Home
import React from 'react'

function Actives() {
    return (
        <h1>Активы</h1>
    )
}

export default Actives
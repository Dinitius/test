import React from 'react'

function Settings() {
    return (
        <h1>Настройки</h1>
    )
}

export default Settings
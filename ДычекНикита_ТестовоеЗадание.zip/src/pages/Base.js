import React from 'react'

function Base() {
    return (
        <h1>База знаний</h1>
    )
}

export default Base